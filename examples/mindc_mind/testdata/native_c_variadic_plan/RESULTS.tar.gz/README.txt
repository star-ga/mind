Observed MIND verdict streams and fixed binary receipts from the frozen campaign.
Compiler stdout includes generated native ELF bytes and backend output paths; those raw compiler stdout files and executable artifacts are retained in operator evidence, not this portable receipt package.
BUILD_HASHES.tsv identifies all sixteen resulting artifacts; build exits and stderr are included unchanged.
No test expectations or stdout/stderr bytes were masked.
