# Independent observation capsule

Author: STARGA Inc.

A portable subset of the independent source/execution review, not its complete
raw archive. Original report SHA256:
2273e834feb105c1998844115b2b8b94e6e77904d9589543c404c1e5bca522ea
Original375-file seal SHA256:
4ee4c9520661bed33fefd8a002746bca9080331182b76d8953056b06e4d3e7cd
Original command-bearing receipt SHA256: 184e17226b254c293656a5dcd0d996481bf4038236a1d7222423841b96516ba3

The reviewer ran16 logical controls /74 processes with copied author-built
artifacts: no independent fresh compiler build is claimed. MIND alone compares
semantic expectations. Original55/8 author controls remain separate.
OBSERVED.tsv is a path-free projection of recorded process metadata, not a new
execution or a replacement for raw protocol streams. Streams copied here are
unchanged. Raw C capture stdout and replay inputs containing process addresses
are omitted; their exact hashes remain recorded. No ELF or private tool path
is included.

The extent-before directory preserves original205575c1 source and wrong-stage
normal exit1/0LF outputs on X01/X02; final94c1e97f returns72 and empty streams
for the same input bytes. These are separate from eight emitter source mutants.

To reproduce the seven I01-I07 calls, first run the documented main suite with
matching instrument identities, then feed each inputs/I*.input to its baseline
MIND constructor, execute the returned unbound artifact using run/capture, and
feed inputs/I*.verify followed by that raw capture to the separate MIND verifier.
Compare its fd3 bytes to inputs/I*.semantic. I08-I10 are constructor-only normal
product refusals; X01/X02 are setup refusals72. Use the same 2GiB/noSwap and
10CPU/12wall child limits. The complete independent raw runner, calibration
inputs, commands and source manifest remain in the original sealed review.
