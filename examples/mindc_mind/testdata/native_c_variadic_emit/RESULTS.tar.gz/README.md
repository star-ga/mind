# Bounded variadic emitter observations

Final guarded driver94c1e97f; product1cb4617a; source sealb834c8c2.
55 original controls and eight real source mutations on both builders.
MIND assertion stdout/stderr/exit, unbound code and canonical semantic receipts
are unmodified. Raw capture frames contain process-specific addresses and are
retained in the private complete run; their exact hashes are listed here.
No raw capture is relabeled as a canonical receipt. Compiler stdout containing
local paths and compiled ELFs are omitted; executable identities remain recorded.
Four same-backend fresh artifacts and12 repeated calls are separate repeat
evidence, not additional controls. No source admission, consumer pin, broader
FP-environment determinism or original MIND-Lab acceptance is claimed.
