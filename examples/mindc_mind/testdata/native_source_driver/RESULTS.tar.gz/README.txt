Candidate source adapter observations, not compiler qualification.
All48 builds were fresh.316 process receipts; original38/4 and76/2 contracts
retained; separate3/1 SHA-return controls. Raw non-ELF runtime streams included.
ELF image outputs and build stdout/stderr are indexed by hash only; executable
bytes and absolute command paths are omitted. Full raw receipts are retained
privately. Reproduce with native_source_driver_check.py and documented hashed
instruments. This transport archive is not a MIC, signature or theorem proof.
